=== Additional Discount ===
Contributors: YourName
Tags: woocommerce, discount, additional discount, cart discount, order discount
Requires at least: 5.0
Tested up to: 6.4
Requires PHP: 7.2
Stable tag: 1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

== Description ==

Additional Discount is a WooCommerce plugin that applies a configurable percentage discount to orders exceeding a specified amount. The discount is displayed on the cart, checkout, order summary, and thank you pages. Admins can customize discount settings from the WooCommerce settings panel.

== Features ==

- **Configurable Discount Percentage** - Set the discount amount in WooCommerce settings.
- **Minimum Order Amount** - Define the minimum amount required to activate the discount.
- **Enable/Disable Feature** - Admins can turn the discount on or off.
- **WooCommerce Integration** - Works seamlessly with cart, checkout, and order pages.
- **Saves Discount in Orders** - The discount is stored in the order details and displayed in the admin panel.
- **Translation Ready** - Comes with a `/languages/` folder for localization.

== Installation ==

1. Download the plugin zip file.
2. Go to **Plugins → Add New** in your WordPress dashboard.
3. Click **Upload Plugin** and select the zip file.
4. Install and activate the plugin.
5. Configure the settings in **WooCommerce → Settings → Additional Discount**.

== Frequently Asked Questions ==

= Can I change the discount percentage? =
Yes, you can set the discount percentage in the WooCommerce settings under the "Additional Discount" tab.

= Does this plugin work with all WooCommerce themes? =
Yes, the plugin works with any theme that supports WooCommerce.

= Is this plugin translation-ready? =
Yes, the plugin includes a `/languages/` folder for localization.

== Changelog ==

= 1.0 =
* Initial release with discount settings, WooCommerce integration, and admin order details support.