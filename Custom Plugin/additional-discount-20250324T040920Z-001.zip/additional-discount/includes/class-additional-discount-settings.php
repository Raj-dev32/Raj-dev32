<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

/**
 * Additional Discount Settings Page for WooCommerce
 */
class Additional_Discount_Settings extends WC_Settings_Page {
    /**
     * Constructor
     */
    public function __construct() {
        $this->id    = 'additional_discount';
        $this->label = __('Additional Discount', 'additional-discount');

        add_filter('woocommerce_settings_tabs_array', [$this, 'add_settings_tab'], 50);
        add_action('woocommerce_settings_tabs_' . $this->id, [$this, 'settings_tab']);
        add_action('woocommerce_update_options_' . $this->id, [$this, 'update_settings']);
    }

    /**
     * Add settings tab to WooCommerce
     *
     * @param array $tabs Existing settings tabs
     * @return array Updated settings tabs
     */
    public function add_settings_tab($tabs) {
        $tabs[$this->id] = $this->label;
        return $tabs;
    }

    /**
     * Display settings page
     */
    public function settings_tab() {
        woocommerce_admin_fields($this->get_settings());
    }

    /**
     * Save settings
     */
    public function update_settings() {
        woocommerce_update_options($this->get_settings());
    }

    /**
     * Define settings fields
     *
     * @return array Settings array
     */
    public function get_settings() {
        return [
            [
                'title' => __('Additional Discount Settings', 'additional-discount'),
                'type'  => 'title',
                'id'    => 'additional_discount_options',
            ],
            [
                'title'   => __('Enable Discount', 'additional-discount'),
                'desc'    => __('Enable additional discount for customers.', 'additional-discount'),
                'id'      => 'additional_discount_enabled',
                'default' => 'yes',
                'type'    => 'checkbox',
                'class'   => 'additional-discount-toggle',
            ],
            [
                'title'   => __('Minimum Order Amount', 'additional-discount'),
                'desc'    => __('Minimum order amount to apply the discount.', 'additional-discount'),
                'id'      => 'additional_discount_min_amount',
                'default' => 499,
                'type'    => 'number',
                'class'   => 'additional-discount-input',
                'custom_attributes' => ['min' => 0, 'step' => 1],
            ],
            [
                'title'   => __('Discount Percentage', 'additional-discount'),
                'desc'    => __('Discount percentage applied on orders.', 'additional-discount'),
                'id'      => 'additional_discount_percentage',
                'default' => 5,
                'type'    => 'number',
                'class'   => 'additional-discount-input',
                'custom_attributes' => ['min' => 0, 'max' => 100, 'step' => 0.1],
            ],
            [
                'type' => 'sectionend',
                'id'   => 'additional_discount_options',
            ],
        ];
    }
}