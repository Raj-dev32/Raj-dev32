<?php
if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

/**
 * Core Discount Application Logic
 */
class Additional_Discount_Core {
    /**
     * Apply discount to cart
     */
    public static function apply_discount() {
        if (is_admin() && !defined('DOING_AJAX')) {
            return;
        }

        $enabled = get_option('additional_discount_enabled', 'yes');
        $min_amount = floatval(get_option('additional_discount_min_amount', 499));
        $discount_percentage = floatval(get_option('additional_discount_percentage', 5));

        if ($enabled !== 'yes' || $discount_percentage <= 0) {
            return;
        }

        $cart = WC()->cart;
        $total = $cart->get_subtotal();

        if ($total >= $min_amount) {
            $discount = $total * ($discount_percentage / 100);
            $discount_label = sprintf(__('Additional Discount (%g%%)', 'additional-discount'), $discount_percentage);
            $cart->add_fee($discount_label, -$discount);
        }
    }

    /**
     * Save discount as order meta
     *
     * @param WC_Order $order Order object
     * @param array $data Order data
     */
    public static function save_order_meta($order, $data) {
        $enabled = get_option('additional_discount_enabled', 'yes');
        $min_amount = floatval(get_option('additional_discount_min_amount', 499));
        $discount_percentage = floatval(get_option('additional_discount_percentage', 5));

        if ($enabled !== 'yes' || $discount_percentage <= 0) {
            return;
        }

        $total = WC()->cart->get_subtotal();
        if ($total >= $min_amount) {
            $discount = $total * ($discount_percentage / 100);
            $order->update_meta_data('_additional_discount', $discount);
        }
    }

    /**
     * Display discount in admin order totals
     *
     * @param int $order_id Order ID
     */
    public static function display_admin_order_meta($order_id) {
        $discount = get_post_meta($order_id, '_additional_discount', true);
        $discount_percentage = floatval(get_option('additional_discount_percentage', 5));

        if ($discount > 0) {
            $discount_label = sprintf(__('Additional Discount (%g%%)', 'additional-discount'), $discount_percentage);
            printf(
                '<tr><td class="label">%s:</td><td>%s</td></tr>',
                esc_html($discount_label),
                wc_price(floatval($discount))
            );
        }
    }
}