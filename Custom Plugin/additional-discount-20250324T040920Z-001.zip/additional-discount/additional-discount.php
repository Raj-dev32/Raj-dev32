<?php
/**
 * Plugin Name: Additional Discount
 * Plugin URI: https://yourwebsite.com/
 * Description: Applies a configurable discount on orders above a specified amount.
 * Version: 1.0
 * Author: Your Name
 * Author URI: https://yourwebsite.com/
 * Text Domain: additional-discount
 * Domain Path: /languages
 * License: GPL v2 or later
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// Define plugin constants
define('ADDITIONAL_DISCOUNT_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('ADDITIONAL_DISCOUNT_VERSION', '1.0');

/**
 * Load text domain for translations
 */
function additional_discount_load_textdomain() {
    load_plugin_textdomain('additional-discount', false, dirname(plugin_basename(__FILE__)) . '/languages');
}
add_action('plugins_loaded', 'additional_discount_load_textdomain');

/**
 * Initialize the plugin
 */
function additional_discount_init() {
    // Check if WooCommerce is active
    if (!class_exists('WooCommerce')) {
        add_action('admin_notices', function () {
            printf('<div class="notice notice-error"><p><strong>%s:</strong> %s</p></div>',
                esc_html__('Additional Discount', 'additional-discount'),
                esc_html__('WooCommerce must be installed and activated for this plugin to work.', 'additional-discount')
            );
        });
        return;
    }

    // Ensure WC_Settings_Page is loaded
    if (!class_exists('WC_Settings_Page') && function_exists('WC')) {
        require_once WC()->plugin_path() . '/includes/admin/settings/class-wc-settings-page.php';
    }

    // Include plugin classes
    require_once ADDITIONAL_DISCOUNT_PLUGIN_DIR . 'includes/class-additional-discount-settings.php';
    require_once ADDITIONAL_DISCOUNT_PLUGIN_DIR . 'includes/class-additional-discount-core.php';

    // Instantiate settings class
    new Additional_Discount_Settings();

    // Enqueue admin styles
    add_action('admin_enqueue_scripts', function ($hook) {
        if ($hook === 'woocommerce_page_wc-settings') {
            wp_enqueue_style(
                'additional-discount-admin',
                plugin_dir_url(__FILE__) . 'assets/admin-style.css',
                [],
                ADDITIONAL_DISCOUNT_VERSION
            );
        }
    });

    // Register WooCommerce hooks
    add_action('woocommerce_cart_calculate_fees', 'Additional_Discount_Core::apply_discount');
    add_action('woocommerce_checkout_create_order', 'Additional_Discount_Core::save_order_meta', 20, 2);
    add_action('woocommerce_admin_order_totals_after_total', 'Additional_Discount_Core::display_admin_order_meta', 10, 1);
}
add_action('plugins_loaded', 'additional_discount_init', 50);

/**
 * Plugin activation hook
 */
function additional_discount_activate() {
    $defaults = [
        'additional_discount_enabled' => 'yes',
        'additional_discount_min_amount' => 499,
        'additional_discount_percentage' => 5,
    ];
    foreach ($defaults as $option => $value) {
        if (get_option($option) === false) {
            add_option($option, $value);
        }
    }
}
register_activation_hook(__FILE__, 'additional_discount_activate');

/**
 * Plugin deactivation hook
 */
function additional_discount_deactivate() {
    delete_option('additional_discount_enabled');
    delete_option('additional_discount_min_amount');
    delete_option('additional_discount_percentage');
}
register_deactivation_hook(__FILE__, 'additional_discount_deactivate');