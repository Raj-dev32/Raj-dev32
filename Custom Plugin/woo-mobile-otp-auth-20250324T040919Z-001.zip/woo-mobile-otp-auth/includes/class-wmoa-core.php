<?php
/**
 * Core class for WooCommerce Mobile OTP Auth plugin.
 *
 * Handles initialization, script enqueuing, and template overrides.
 *
 * @package WooCommerceMobileOTPAuth
 */
class WMOA_Core {
    /**
     * Constructor.
     */
    public function __construct() {
        // Include other classes
        require_once plugin_dir_path(__FILE__) . '/class-wmoa-registration.php';
        require_once plugin_dir_path(__FILE__) . '/class-wmoa-login.php';
        require_once plugin_dir_path(__FILE__) . '/class-wmoa-sms-api.php';
        require_once plugin_dir_path(__FILE__) . '/class-wmoa-settings.php';
    }

    /**
     * Initialize the plugin.
     */
    public function init() {
        // Instantiate classes
        $this->registration = new WMOA_Registration();
        $this->login = new WMOA_Login();
        $this->settings = new WMOA_Settings();

        // Enqueue scripts and styles
        add_action('wp_enqueue_scripts', [$this, 'enqueue_scripts']);

        // Remove default WooCommerce forms and load custom template
        add_action('init', [$this, 'remove_default_forms']);
    }

    /**
     * Enqueue scripts and styles.
     */
    public function enqueue_scripts() {
        wp_enqueue_style('dashicons');
        wp_enqueue_style('wmoa-styles', plugin_dir_url(__FILE__) . '../assets/css/wmoa-styles.css', [], '1.5');
        wp_enqueue_script('jquery');
        wp_enqueue_script('wmoa-script', plugin_dir_url(__FILE__) . '../assets/js/wmoa-script.js', ['jquery'], '1.5', true);

        $ajax_data = [
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce'    => wp_create_nonce('wmoa_nonce'),
        ];
        wp_localize_script('wmoa-script', 'wmoa_ajax', $ajax_data);
    }

    /**
     * Remove default WooCommerce login and registration forms and load custom template.
     */
    public function remove_default_forms() {
        // Remove default login form actions
        remove_action('woocommerce_login_form_start', 'wc_login_form_start');
        remove_action('woocommerce_login_form', 'wc_login_form');
        remove_action('woocommerce_login_form_end', 'wc_login_form_end');

        // Remove default registration form actions
        remove_action('woocommerce_register_form_start', 'wc_registration_form_start');
        remove_action('woocommerce_register_form', 'wc_registration_form');
        remove_action('woocommerce_register_form_end', 'wc_registration_form_end');

        // Filter the template to load the custom template
        add_filter('wc_get_template', [$this, 'load_custom_template'], 10, 5);
    }

    /**
     * Load custom login/registration template.
     *
     * @param string $template      The path to the template file.
     * @param string $template_name The name of the template.
     * @param array  $args          Arguments passed to the template.
     * @param string $template_path The template path.
     * @param string $default_path  The default path.
     * @return string The updated template path.
     */
    public function load_custom_template($template, $template_name, $args, $template_path, $default_path) {
        if ($template_name === 'myaccount/form-login.php') {
            $custom_template = plugin_dir_path(__FILE__) . '../templates/wmoa-login-tm.php';
            if (file_exists($custom_template)) {
                return $custom_template;
            }
            return plugin_dir_path(__FILE__) . '../templates/empty.php';
        }
        return $template;
    }
}