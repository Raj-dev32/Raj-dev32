<?php
/**
 * Login class for WooCommerce Mobile OTP Auth plugin.
 *
 * Handles OTP-based and password-based login functionality.
 *
 * @package WooCommerceMobileOTPAuth
 */
class WMOA_Login {
    /**
     * Constructor.
     */
    public function __construct() {
        add_action('wp_ajax_wmoa_login_send_otp', [$this, 'send_login_otp']);
        add_action('wp_ajax_nopriv_wmoa_login_send_otp', [$this, 'send_login_otp']);
        add_action('wp_ajax_wmoa_login_verify_otp', [$this, 'verify_login_otp']);
        add_action('wp_ajax_nopriv_wmoa_login_verify_otp', [$this, 'verify_login_otp']);
        add_filter('authenticate', [$this, 'login_with_phone'], 20, 3);
    }

    /**
     * Display the custom login form with tabs for OTP and password login.
     */
    public function custom_login_form() {
        if (is_user_logged_in()) {
            return;
        }
        ?>
        <div class="wmoa-form-wrapper">
            <h3 class="wmoa-form-title"><?php esc_html_e('Login', 'woo-mobile-otp-auth'); ?></h3>
            <div class="wmoa-login-tabs">
                <ul class="wmoa-tab-nav">
                    <li class="wmoa-tab active" data-tab="otp-login"><i class="fas fa-mobile-alt"></i> <?php esc_html_e('Login with OTP', 'woo-mobile-otp-auth'); ?></li>
                    <li class="wmoa-tab" data-tab="password-login"><i class="fas fa-lock"></i> <?php esc_html_e('Login with Password', 'woo-mobile-otp-auth'); ?></li>
                </ul>

                <!-- OTP Login Tab -->
                <div id="otp-login" class="wmoa-tab-content active">
                    <form method="post" id="phone-login-form" class="wmoa-otp-form">
                        <p class="wmoa-form-row">
                            <label for="login_billing_phone"><?php esc_html_e('Phone Number', 'woo-mobile-otp-auth'); ?> <span class="required">*</span></label>
                            <span class="wmoa-phone-input-wrapper">
                                <span class="wmoa-country-code">+91</span>
                                <input type="text" class="wmoa-input" name="login_phone" id="login_billing_phone" maxlength="10" required placeholder="<?php esc_attr_e('Enter 10-digit mobile number', 'woo-mobile-otp-auth'); ?>" value="<?php echo esc_attr($_POST['login_phone'] ?? ''); ?>" />
                            </span>
                            <p id="login-phone-error" class="wmoa-error"></p>
                        </p>
                        <p class="wmoa-form-row">
                            <button type="button" id="loginSendOtp" class="wmoa-button"><?php esc_html_e('Get OTP', 'woo-mobile-otp-auth'); ?></button>
                        </p>
                        <div id="login-otp-section" style="display:none;">
                            <p class="wmoa-form-row">
                                <label for="login_otp_code"><?php esc_html_e('Enter OTP', 'woo-mobile-otp-auth'); ?> <span class="required">*</span></label>
                                <input type="text" class="wmoa-input" name="login_otp_code" id="login_otp_code" maxlength="6" required placeholder="<?php esc_attr_e('6-digit OTP', 'woo-mobile-otp-auth'); ?>" />
                            </p>
                            <p class="wmoa-form-row">
                                <button type="button" id="loginVerifyOtpBtn" class="wmoa-button"><?php esc_html_e('Verify OTP', 'woo-mobile-otp-auth'); ?></button>
                            </p>
                            <p id="login-otp-message" class="wmoa-message"></p>
                            <a href="#" id="loginResendOtp" class="wmoa-resend-otp disabled"><?php esc_html_e('Resend OTP', 'woo-mobile-otp-auth'); ?> (<span id="loginResendTimer">60</span>s)</a>
                        </div>
                    </form>
                </div>

                <!-- Password Login Tab -->
                <div id="password-login" class="wmoa-tab-content">
                    <?php
                    // Display WooCommerce notices within the form
                    if (function_exists('wc_print_notices')) {
                        echo '<div class="wmoa-wc-notices">';
                        wc_print_notices();
                        echo '</div>';
                    }
                    ?>
                    <form method="post" id="password-login-form" class="wmoa-password-form">
                        <p class="wmoa-form-row">
                            <label for="username"><?php esc_html_e('Username or Email', 'woo-mobile-otp-auth'); ?> <span class="required">*</span></label>
                            <input type="text" class="wmoa-input" name="username" id="username" required placeholder="<?php esc_attr_e('Enter your username or email', 'woo-mobile-otp-auth'); ?>" value="<?php echo esc_attr($_POST['username'] ?? ''); ?>" />
                        </p>
                        <p class="wmoa-form-row">
                            <label for="password"><?php esc_html_e('Password', 'woo-mobile-otp-auth'); ?> <span class="required">*</span></label>
                            <input type="password" class="wmoa-input" name="password" id="password" required placeholder="<?php esc_attr_e('Enter your password', 'woo-mobile-otp-auth'); ?>" />
                            <span class="wmoa-password-toggle" data-target="password"><i class="fas fa-eye"></i></span>
                        </p>
                        <p class="wmoa-form-row">
                            <?php wp_nonce_field('woocommerce-login', 'woocommerce-login-nonce'); ?>
                            <button type="submit" class="wmoa-button" name="login" value="login"><?php esc_html_e('Login', 'woo-mobile-otp-auth'); ?></button>
                            <input type="hidden" name="redirect" value="<?php echo esc_url(wc_get_account_endpoint_url('dashboard')); ?>" />
                        </p>
                    </form>
                </div>
            </div>
        </div>
        <?php
    }

    /**
     * Handle sending login OTP via AJAX.
     */
    public function send_login_otp() {
        // Check nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['nonce'])), 'wmoa_nonce')) {
            wp_send_json_error(['message' => esc_html__('Security check failed', 'woo-mobile-otp-auth')]);
            return;
        }

        // Check phone parameter
        if (!isset($_POST['phone']) || empty($_POST['phone'])) {
            wp_send_json_error(['message' => esc_html__('Phone number is required', 'woo-mobile-otp-auth')]);
            return;
        }

        $phone = sanitize_text_field(wp_unslash($_POST['phone']));
        $user = get_users([
            'meta_key'   => 'billing_phone',
            'meta_value' => $phone,
            'number'     => 1,
        ]);

        if (empty($user)) {
            wp_send_json_error(['message' => esc_html__('Phone number not registered. Please register first.', 'woo-mobile-otp-auth')]);
            return;
        }

        $last_sent = get_option("wmoa_login_otp_last_sent_$phone");
        if ($last_sent && (time() - $last_sent < 60)) {
            wp_send_json_error(['message' => esc_html__('Please wait 60 seconds before requesting a new OTP.', 'woo-mobile-otp-auth')]);
            return;
        }

        $otp = rand(100000, 999999);
        update_option("wmoa_login_otp_$phone", $otp, false);
        update_option("wmoa_login_otp_last_sent_$phone", time(), false);

        $sms_api = new WMOA_SMS_API();
        $result = $sms_api->send_sms($phone, sprintf(__('Your Arutoys login OTP is %s.', 'woo-mobile-otp-auth'), $otp));

        if ($result['success']) {
            wp_send_json_success([
                'message' => esc_html__('OTP sent successfully', 'woo-mobile-otp-auth'),
                'otp'     => $otp, // Include OTP in the response for testing
            ]);
        } else {
            wp_send_json_error(['message' => esc_html__('Error sending OTP', 'woo-mobile-otp-auth')]);
        }
    }

    /**
     * Handle login OTP verification via AJAX.
     */
    public function verify_login_otp() {
        // Check nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['nonce'])), 'wmoa_nonce')) {
            wp_send_json_error(['message' => esc_html__('Security check failed', 'woo-mobile-otp-auth')]);
            return;
        }

        // Check parameters
        if (!isset($_POST['phone']) || !isset($_POST['otp'])) {
            wp_send_json_error(['message' => esc_html__('Missing parameters', 'woo-mobile-otp-auth')]);
            return;
        }

        $phone = sanitize_text_field(wp_unslash($_POST['phone']));
        $otp_entered = sanitize_text_field(wp_unslash($_POST['otp']));
        $stored_otp = get_option("wmoa_login_otp_$phone");

        if ($otp_entered != $stored_otp) {
            wp_send_json_error(['message' => esc_html__('Invalid OTP', 'woo-mobile-otp-auth')]);
            return;
        }

        $user = get_users([
            'meta_key'   => 'billing_phone',
            'meta_value' => $phone,
            'number'     => 1,
        ])[0];

        wp_set_current_user($user->ID);
        wp_set_auth_cookie($user->ID);
        delete_option("wmoa_login_otp_$phone");

        wp_send_json_success(['message' => esc_html__('Login successful', 'woo-mobile-otp-auth')]);
    }

    /**
     * Allow login with phone number for OTP (not used for username/password login).
     *
     * @param WP_User|WP_Error|null $user     The user object or error.
     * @param string                $username The username (phone number).
     * @param string                $password The password.
     * @return WP_User|WP_Error|null The authenticated user or error.
     */
    public function login_with_phone($user, $username, $password) {
        return $user;
    }
}