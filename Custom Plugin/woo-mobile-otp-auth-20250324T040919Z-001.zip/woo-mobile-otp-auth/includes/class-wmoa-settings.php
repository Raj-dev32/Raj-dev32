<?php
/**
 * Settings class for WooCommerce Mobile OTP Auth plugin.
 *
 * Handles the WooCommerce settings tab and fields for SMS API configuration.
 *
 * @package WooCommerceMobileOTPAuth
 */
class WMOA_Settings {
    /**
     * Constructor.
     */
    public function __construct() {
        // Add WooCommerce settings tab
        add_filter('woocommerce_settings_tabs_array', [$this, 'add_settings_tab'], 50);
        add_action('woocommerce_settings_tabs_wmoa_settings', [$this, 'settings_tab']);
        add_action('woocommerce_update_options_wmoa_settings', [$this, 'update_settings']);
    }

    /**
     * Add settings tab to WooCommerce.
     *
     * @param array $settings_tabs Existing settings tabs.
     * @return array Updated settings tabs.
     */
    public function add_settings_tab($settings_tabs) {
        $settings_tabs['wmoa_settings'] = esc_html__('WMOA Settings', 'woo-mobile-otp-auth');
        return $settings_tabs;
    }

    /**
     * Display the settings tab content.
     */
    public function settings_tab() {
        woocommerce_admin_fields($this->get_settings());
    }

    /**
     * Update settings when saved.
     */
    public function update_settings() {
        woocommerce_update_options($this->get_settings());
    }

    /**
     * Define the settings fields.
     *
     * @return array Settings fields.
     */
    private function get_settings() {
        $settings = [
            'section_title' => [
                'name'     => esc_html__('WMOA Settings', 'woo-mobile-otp-auth'),
                'type'     => 'title',
                'desc'     => '',
                'id'       => 'wmoa_settings_section_title',
            ],
            'enable_wmoa' => [
                'name'     => esc_html__('Enable WMOA', 'woo-mobile-otp-auth'),
                'type'     => 'checkbox',
                'desc'     => esc_html__('Enable or disable the WMOA SMS functionality', 'woo-mobile-otp-auth'),
                'id'       => 'wmoa_enable_wmoa',
                'default'  => 'yes',
            ],
            'sms_username' => [
                'name'     => esc_html__('SMS API Username', 'woo-mobile-otp-auth'),
                'type'     => 'text',
                'desc'     => esc_html__('Enter your BulkSMS API username', 'woo-mobile-otp-auth'),
                'id'       => 'wmoa_sms_username',
                'default'  => 'arutoys',
            ],
            'sms_password' => [
                'name'     => esc_html__('SMS API Password', 'woo-mobile-otp-auth'),
                'type'     => 'password',
                'desc'     => esc_html__('Enter your BulkSMS API password', 'woo-mobile-otp-auth'),
                'id'       => 'wmoa_sms_password',
                'default'  => 'OlixLab$1',
            ],
            'sms_api_url' => [
                'name'     => esc_html__('SMS API URL', 'woo-mobile-otp-auth'),
                'type'     => 'text',
                'desc'     => esc_html__('Enter the BulkSMS API URL', 'woo-mobile-otp-auth'),
                'id'       => 'wmoa_sms_api_url',
                'default'  => 'https://api.bulksms.com/v1/messages?auto-unicode=true&longMessageMaxParts=30',
            ],
            'testing_mode' => [
                'name'     => esc_html__('Testing Mode', 'woo-mobile-otp-auth'),
                'type'     => 'checkbox',
                'desc'     => esc_html__('Enable testing mode (no real SMS will be sent)', 'woo-mobile-otp-auth'),
                'id'       => 'wmoa_testing_mode',
                'default'  => 'yes',
            ],
            'section_end' => [
                'type'     => 'sectionend',
                'id'       => 'wmoa_settings_section_end',
            ],
        ];

        return apply_filters('wmoa_settings', $settings);
    }
}