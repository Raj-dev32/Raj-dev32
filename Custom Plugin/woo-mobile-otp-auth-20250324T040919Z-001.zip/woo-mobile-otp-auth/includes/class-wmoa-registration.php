<?php
/**
 * Registration class for WooCommerce Mobile OTP Auth plugin.
 *
 * Handles OTP-based and traditional (username/email/password) registration functionality.
 *
 * @package WooCommerceMobileOTPAuth
 */
class WMOA_Registration {
    /**
     * Constructor.
     */
    public function __construct() {
        add_action('wp_ajax_send_otp', [$this, 'send_otp']);
        add_action('wp_ajax_nopriv_send_otp', [$this, 'send_otp']);
        add_action('wp_ajax_verify_otp', [$this, 'verify_otp']);
        add_action('wp_ajax_nopriv_verify_otp', [$this, 'verify_otp']);
        add_action('init', [$this, 'register_after_otp']);
        add_action('init', [$this, 'register_with_password']);
    }

    /**
     * Display the custom registration form with tabs for OTP and password registration.
     */
    public function custom_registration_form() {
        if (is_user_logged_in()) {
            echo '<p>' . esc_html__('You are already logged in.', 'woo-mobile-otp-auth') . '</p>';
            return;
        }
        ?>
        <div class="wmoa-form-wrapper">
            <h3 class="wmoa-form-title"><?php esc_html_e('Register', 'woo-mobile-otp-auth'); ?></h3>
            <div class="wmoa-registration-tabs">
                <ul class="wmoa-tab-nav">
                    <li class="wmoa-tab active" data-tab="otp-registration"><i class="fas fa-mobile-alt"></i> <?php esc_html_e('Register with OTP', 'woo-mobile-otp-auth'); ?></li>
                    <li class="wmoa-tab" data-tab="password-registration"><i class="fas fa-lock"></i> <?php esc_html_e('Register with Password', 'woo-mobile-otp-auth'); ?></li>
                </ul>

                <!-- OTP Registration Tab -->
                <div id="otp-registration" class="wmoa-tab-content active">
                    <form method="post" id="phone-register-form" class="wmoa-otp-form">
                        <p class="wmoa-form-row">
                            <label for="reg_billing_phone"><?php esc_html_e('Phone Number', 'woo-mobile-otp-auth'); ?> <span class="required">*</span></label>
                            <span class="wmoa-phone-input-wrapper">
                                <span class="wmoa-country-code">+91</span>
                                <input type="text" class="wmoa-input" name="billing_phone" id="reg_billing_phone" maxlength="10" required placeholder="<?php esc_attr_e('Enter 10-digit mobile number', 'woo-mobile-otp-auth'); ?>" value="<?php echo esc_attr($_POST['billing_phone'] ?? ''); ?>" />
                            </span>
                            <p id="phone-error" class="wmoa-error"></p>
                        </p>
                        <p class="wmoa-form-row">
                            <button type="button" id="sendOtp" class="wmoa-button"><?php esc_html_e('Get OTP', 'woo-mobile-otp-auth'); ?></button>
                        </p>
                        <div id="otp-section" style="display:none;">
                            <p class="wmoa-form-row">
                                <label for="otp_code"><?php esc_html_e('Enter OTP', 'woo-mobile-otp-auth'); ?> <span class="required">*</span></label>
                                <input type="text" class="wmoa-input" name="otp_code" id="otp_code" maxlength="6" required placeholder="<?php esc_attr_e('6-digit OTP', 'woo-mobile-otp-auth'); ?>" />
                            </p>
                            <p class="wmoa-form-row">
                                <button type="button" id="verifyOtpBtn" class="wmoa-button"><?php esc_html_e('Verify OTP', 'woo-mobile-otp-auth'); ?></button>
                            </p>
                            <p id="otp-message" class="wmoa-message"></p>
                            <a href="#" id="resendOtp" class="wmoa-resend-otp disabled"><?php esc_html_e('Resend OTP', 'woo-mobile-otp-auth'); ?> (<span id="resendTimer">60</span>s)</a>
                        </div>
                    </form>
                </div>

                <!-- Password Registration Tab -->
                <div id="password-registration" class="wmoa-tab-content">
                    <?php
                    // Display WooCommerce notices within the form
                    if (function_exists('wc_print_notices')) {
                        echo '<div class="wmoa-wc-notices">';
                        wc_print_notices();
                        echo '</div>';
                    }
                    ?>
                    <form method="post" id="password-register-form" class="wmoa-password-form">
                        <p class="wmoa-form-row">
                            <label for="reg_username"><?php esc_html_e('Username', 'woo-mobile-otp-auth'); ?> <span class="required">*</span></label>
                            <input type="text" class="wmoa-input" name="username" id="reg_username" required placeholder="<?php esc_attr_e('Enter your username', 'woo-mobile-otp-auth'); ?>" value="<?php echo esc_attr($_POST['username'] ?? ''); ?>" />
                        </p>
                        <p class="wmoa-form-row">
                            <label for="reg_email"><?php esc_html_e('Email', 'woo-mobile-otp-auth'); ?> <span class="required">*</span></label>
                            <input type="email" class="wmoa-input" name="email" id="reg_email" required placeholder="<?php esc_attr_e('Enter your email', 'woo-mobile-otp-auth'); ?>" value="<?php echo esc_attr($_POST['email'] ?? ''); ?>" />
                        </p>
                        <p class="wmoa-form-row">
                            <label for="reg_password"><?php esc_html_e('Password', 'woo-mobile-otp-auth'); ?> <span class="required">*</span></label>
                            <input type="password" class="wmoa-input" name="password" id="reg_password" required placeholder="<?php esc_attr_e('Enter your password', 'woo-mobile-otp-auth'); ?>" />
                            <span class="wmoa-password-toggle" data-target="reg_password"><i class="fas fa-eye"></i></span>
                        </p>
                        <p class="wmoa-form-row">
                            <?php wp_nonce_field('wmoa-register-password', 'wmoa-register-nonce'); ?>
                            <button type="submit" class="wmoa-button" name="register_with_password" value="register"><?php esc_html_e('Register', 'woo-mobile-otp-auth'); ?></button>
                        </p>
                    </form>
                </div>
            </div>
        </div>
        <?php
    }

    /**
     * Handle sending OTP via AJAX.
     */
    public function send_otp() {
        // Check if the action is correct
        if (!isset($_POST['action']) || $_POST['action'] !== 'send_otp') {
            wp_send_json_error(['message' => esc_html__('Invalid action', 'woo-mobile-otp-auth')], 400);
            return;
        }

        // Check nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['nonce'])), 'wmoa_nonce')) {
            wp_send_json_error(['message' => esc_html__('Security check failed', 'woo-mobile-otp-auth')], 400);
            return;
        }

        // Check phone parameter
        if (!isset($_POST['phone']) || empty($_POST['phone'])) {
            wp_send_json_error(['message' => esc_html__('Phone number is required', 'woo-mobile-otp-auth')], 400);
            return;
        }

        $phone = trim(sanitize_text_field(wp_unslash($_POST['phone'])));

        // Check phone format
        if (!preg_match('/^[0-9]{10}$/', $phone)) {
            wp_send_json_error(['message' => esc_html__('Invalid phone number format', 'woo-mobile-otp-auth')], 400);
            return;
        }

        // Check if phone number is already registered
        $existing_user = get_users([
            'meta_key'   => 'billing_phone',
            'meta_value' => $phone,
            'number'     => 1,
        ]);

        if (!empty($existing_user)) {
            wp_send_json_error(['message' => esc_html__('This phone number is already registered. Please log in.', 'woo-mobile-otp-auth')], 400);
            return;
        }

        // Check rate limit
        $last_sent = get_option("wmoa_otp_last_sent_$phone");
        if ($last_sent && (time() - $last_sent < 60)) {
            wp_send_json_error(['message' => esc_html__('Please wait 60 seconds before requesting a new OTP.', 'woo-mobile-otp-auth')], 400);
            return;
        }

        // Generate OTP
        $otp = rand(100000, 999999);
        update_option("wmoa_otp_$phone", $otp, false);
        update_option("wmoa_otp_last_sent_$phone", time(), false);

        // Send SMS with OTP
        $sms_api = new WMOA_SMS_API();
        $message = sprintf(__('Welcome to Arutoys! Your OTP is %s.', 'woo-mobile-otp-auth'), $otp);
        $result = $sms_api->send_sms($phone, $message);

        if ($result['success']) {
            wp_send_json_success([
                'message' => esc_html__('OTP sent successfully', 'woo-mobile-otp-auth'),
                'otp'     => $otp, // Include OTP in the response for testing
            ]);
        } else {
            wp_send_json_error(['message' => esc_html__('Error sending OTP', 'woo-mobile-otp-auth')], 500);
        }
    }

    /**
     * Handle OTP verification via AJAX.
     */
    public function verify_otp() {
        // Check nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['nonce'])), 'wmoa_nonce')) {
            wp_send_json_error(['message' => esc_html__('Security check failed', 'woo-mobile-otp-auth')]);
            return;
        }

        // Check parameters
        if (!isset($_POST['phone']) || !isset($_POST['otp'])) {
            wp_send_json_error(['message' => esc_html__('Missing parameters', 'woo-mobile-otp-auth')]);
            return;
        }

        $phone = sanitize_text_field(wp_unslash($_POST['phone']));
        $otp_entered = sanitize_text_field(wp_unslash($_POST['otp']));
        $stored_otp = get_option("wmoa_otp_$phone");

        if ($otp_entered != $stored_otp) {
            wp_send_json_error(['message' => esc_html__('Invalid OTP', 'woo-mobile-otp-auth')]);
        } else {
            delete_option("wmoa_otp_$phone");
            wp_send_json_success(['message' => esc_html__('OTP verified', 'woo-mobile-otp-auth')]);
        }
    }

    /**
     * Handle user registration after OTP verification.
     */
    public function register_after_otp() {
        if (!isset($_POST['otp_verified']) || $_POST['otp_verified'] != '1') {
            return;
        }

        $phone = sanitize_text_field(wp_unslash($_POST['billing_phone']));

        $existing_user = get_users([
            'meta_key'   => 'billing_phone',
            'meta_value' => $phone,
            'number'     => 1,
        ]);

        if (!empty($existing_user)) {
            wc_add_notice(esc_html__('This phone number is already registered. Please log in.', 'woo-mobile-otp-auth'), 'error');
            return;
        }

        // Create user without a password
        $userdata = [
            'user_login' => $phone,
            'user_pass'  => '', // No password; user will set it via reset link
            'role'       => 'customer',
        ];

        $user_id = wp_insert_user($userdata);
        if (is_wp_error($user_id)) {
            wc_add_notice(esc_html__('Error creating user. Please try again.', 'woo-mobile-otp-auth'), 'error');
            return;
        }

        // Generate a password reset link
        $user = get_user_by('ID', $user_id);
        $reset_key = get_password_reset_key($user);
        if (is_wp_error($reset_key)) {
            wp_delete_user($user_id);
            wc_add_notice(esc_html__('Error creating user. Please try again.', 'woo-mobile-otp-auth'), 'error');
            return;
        }

        $reset_link = network_site_url("wp-login.php?action=rp&key=$reset_key&login=" . rawurlencode($user->user_login), 'login');

        // Send welcome SMS with reset link
        $sms_api = new WMOA_SMS_API();
        $welcome_message = sprintf(__('Welcome to Arutoys! Set your password here: %s', 'woo-mobile-otp-auth'), $reset_link);
        $sms_api->send_sms($phone, $welcome_message);

        update_user_meta($user_id, 'billing_phone', $phone);
        wp_set_current_user($user_id);
        wp_set_auth_cookie($user_id);

        wp_safe_redirect(site_url('/my-account/edit-account/'));
        exit();
    }

    /**
     * Handle user registration with username/email/password.
     */
    public function register_with_password() {
        if (!isset($_POST['register_with_password']) || !isset($_POST['wmoa-register-nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['wmoa-register-nonce'])), 'wmoa-register-password')) {
            return;
        }

        $username = sanitize_user(wp_unslash($_POST['username'] ?? ''));
        $email = sanitize_email(wp_unslash($_POST['email'] ?? ''));
        $password = wp_unslash($_POST['password'] ?? '');

        // Validate inputs
        if (empty($username) || empty($email) || empty($password)) {
            wc_add_notice(esc_html__('All fields are required.', 'woo-mobile-otp-auth'), 'error');
            return;
        }

        if (!is_email($email)) {
            wc_add_notice(esc_html__('Invalid email address.', 'woo-mobile-otp-auth'), 'error');
            return;
        }

        if (username_exists($username)) {
            wc_add_notice(esc_html__('Username already exists.', 'woo-mobile-otp-auth'), 'error');
            return;
        }

        if (email_exists($email)) {
            wc_add_notice(esc_html__('Email address already registered.', 'woo-mobile-otp-auth'), 'error');
            return;
        }

        // Create user
        $userdata = [
            'user_login' => $username,
            'user_email' => $email,
            'user_pass'  => $password,
            'role'       => 'customer',
        ];

        $user_id = wp_insert_user($userdata);
        if (is_wp_error($user_id)) {
            wc_add_notice(esc_html__('Error creating user: ' . $user_id->get_error_message(), 'woo-mobile-otp-auth'), 'error');
            return;
        }

        // Log the user in
        wp_set_current_user($user_id);
        wp_set_auth_cookie($user_id);

        wp_safe_redirect(site_url('/my-account/edit-account/'));
        exit();
    }
}