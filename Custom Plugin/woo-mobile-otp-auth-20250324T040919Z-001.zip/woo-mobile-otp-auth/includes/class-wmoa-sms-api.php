<?php
/**
 * SMS API class for WooCommerce Mobile OTP Auth plugin.
 *
 * Handles sending SMS messages via the BulkSMS API.
 *
 * @package WooCommerceMobileOTPAuth
 */
class WMOA_SMS_API {
    /**
     * @var string SMS API username.
     */
    private $username;

    /**
     * @var string SMS API password.
     */
    private $password;

    /**
     * @var string SMS API URL.
     */
    private $api_url;

    /**
     * @var bool Whether testing mode is enabled.
     */
    private $testing_mode;

    /**
     * @var bool Whether the SMS functionality is enabled.
     */
    private $enabled;

    /**
     * Constructor.
     */
    public function __construct() {
        // Load settings dynamically
        $this->username      = get_option('wmoa_sms_username', 'arutoys');
        $this->password      = get_option('wmoa_sms_password', 'OlixLab$1');
        $this->api_url       = get_option('wmoa_sms_api_url', 'https://api.bulksms.com/v1/messages?auto-unicode=true&longMessageMaxParts=30');
        $this->testing_mode  = get_option('wmoa_testing_mode', 'yes') === 'yes';
        $this->enabled       = get_option('wmoa_enable_wmoa', 'yes') === 'yes';
    }

    /**
     * Send an SMS message.
     *
     * @param string $mobile  The recipient's mobile number.
     * @param string $message The message to send.
     * @return array An array containing success status and OTP (if applicable).
     */
    public function send_sms($mobile, $message) {
        // If the plugin is disabled, return a failure response
        if (!$this->enabled) {
            return [
                'success' => false,
                'otp'     => null,
            ];
        }

        // Extract OTP from the message (if present)
        preg_match('/OTP is (\d{6})/', $message, $matches);
        $otp = $matches[1] ?? null;

        if ($this->testing_mode) {
            // In testing mode, skip the API call and return success
            return [
                'success' => true,
                'otp'     => $otp,
            ];
        }

        // Production mode: Call the BulkSMS API
        $auth_header = 'Authorization: Basic ' . base64_encode("{$this->username}:{$this->password}");

        $message_data = wp_json_encode([
            'from'          => 'AruToys',
            'to'            => '+91' . $mobile,
            'routingGroup'  => 'ECONOMY',
            'encoding'      => 'TEXT',
            'numberOfParts' => 0,
            'body'          => $message,
        ]);

        $ch = curl_init($this->api_url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, [
            'Content-Type: application/json',
            $auth_header,
        ]);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $message_data);

        $response = curl_exec($ch);
        $http_status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($http_status != 201) {
            return [
                'success' => false,
                'otp'     => $otp,
            ];
        }

        return [
            'success' => true,
            'otp'     => $otp,
        ];
    }
}