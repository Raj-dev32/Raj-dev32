jQuery(document).ready(function($) {
    // Registration Form Elements
    const phoneInput = $('#reg_billing_phone');
    const sendOtpBtn = $('#sendOtp');
    const otpSection = $('#otp-section');
    const otpInput = $('#otp_code');
    const verifyOtpBtn = $('#verifyOtpBtn');
    const otpMessage = $('#otp-message');
    const phoneError = $('#phone-error');
    const resendOtpLink = $('#resendOtp');
    const resendTimer = $('#resendTimer');
  
    // Login Form Elements
    const loginPhoneInput = $('#login_billing_phone');
    const loginSendOtpBtn = $('#loginSendOtp');
    const loginOtpSection = $('#login-otp-section');
    const loginOtpInput = $('#login_otp_code');
    const loginVerifyOtpBtn = $('#loginVerifyOtpBtn');
    const loginOtpMessage = $('#login-otp-message');
    const loginPhoneError = $('#login-phone-error');
    const loginResendOtpLink = $('#loginResendOtp');
    const loginResendTimer = $('#loginResendTimer');
  
    // Ensure wmoa_ajax is defined
    if (typeof wmoa_ajax === 'undefined') {
        otpMessage.text("Error: AJAX configuration missing. Please refresh the page.").addClass('wmoa-error').show();
        loginOtpMessage.text("Error: AJAX configuration missing. Please refresh the page.").addClass('wmoa-error').show();
        return;
    }
  
    // Tab Switching for Both Login and Registration
    $('.wmoa-tab').on('click', function() {
        const tabId = $(this).data('tab');
        
        // Update active tab
        $(this).closest('.wmoa-tab-nav').find('.wmoa-tab').removeClass('active');
        $(this).addClass('active');
  
        // Show/hide tab content
        $(this).closest('.wmoa-login-tabs, .wmoa-registration-tabs').find('.wmoa-tab-content').removeClass('active');
        $('#' + tabId).addClass('active');
  
        // Clear messages when switching tabs
        phoneError.hide();
        otpMessage.hide();
        loginPhoneError.hide();
        loginOtpMessage.hide();
    });
  
    // Password Toggle
    $('.wmoa-password-toggle').on('click', function() {
        const targetId = $(this).data('target');
        const input = $('#' + targetId);
        const icon = $(this).find('i');
        if (input.attr('type') === 'password') {
            input.attr('type', 'text');
            icon.removeClass('fa-eye').addClass('fa-eye-slash');
        } else {
            input.attr('type', 'password');
            icon.removeClass('fa-eye-slash').addClass('fa-eye');
        }
    });
  
    // Resend OTP Timer Function
    function startResendTimer(timerElement, resendLink, duration) {
        let timeLeft = duration;
        timerElement.text(timeLeft);
        resendLink.addClass('disabled');
  
        const timer = setInterval(function() {
            timeLeft--;
            timerElement.text(timeLeft);
            if (timeLeft <= 0) {
                clearInterval(timer);
                resendLink.removeClass('disabled');
                timerElement.text(duration);
            }
        }, 1000);
    }
  
    // Registration: Restrict phone input to 10 digits
    phoneInput.on("input", function() {
        $(this).val($(this).val().replace(/\D/g, '').substring(0, 10));
    });
  
    // Registration: Handle "Get OTP" button click
    sendOtpBtn.on("click", function() {
        const phone = phoneInput.val().trim();
        if (!phone) {
            phoneError.text("Phone number is required.").show();
            return;
        }
        if (phone.length !== 10) {
            phoneError.text("Enter a valid 10-digit phone number.").show();
            return;
        }
        phoneError.hide();
        otpMessage.hide(); // Clear previous messages
  
        sendOtpBtn.addClass('loading').prop("disabled", true);
  
        $.ajax({
            url: wmoa_ajax.ajax_url,
            type: 'POST',
            data: { 
                action: 'send_otp', 
                phone: phone, 
                nonce: wmoa_ajax.nonce 
            },
            dataType: 'json',
            success: function(response) {
                sendOtpBtn.removeClass('loading').prop("disabled", false);
  
                if (response.success) {
                    otpMessage.text(response.data.message).addClass('wmoa-success').removeClass('wmoa-error').show();
                    otpSection.show();
                    startResendTimer(resendTimer, resendOtpLink, 60);
                } else {
                    phoneError.text(response.data.message || 'Unknown error').addClass('wmoa-error').removeClass('wmoa-success').show();
                }
            },
            error: function(xhr, status, error) {
                sendOtpBtn.removeClass('loading').prop("disabled", false);
                let message = 'Error sending OTP: ' + (xhr.responseText || 'Unknown error');
                try {
                    const parsed = JSON.parse(xhr.responseText);
                    if (parsed.data && parsed.data.message) {
                        message = parsed.data.message;
                    }
                } catch (e) {
                    // Ignore parsing error
                }
                phoneError.text(message).addClass('wmoa-error').removeClass('wmoa-success').show();
            }
        });
    });
  
    // Registration: Handle "Resend OTP" click
    resendOtpLink.on('click', function(e) {
        e.preventDefault();
        if ($(this).hasClass('disabled')) return;
  
        sendOtpBtn.trigger('click');
    });
  
    // Registration: Handle "Verify OTP" button click
    verifyOtpBtn.on("click", function() {
        const phone = phoneInput.val().trim();
        const otp = otpInput.val();
  
        if (otp.length !== 6) {
            otpMessage.text("Enter a valid 6-digit OTP.").addClass('wmoa-error').removeClass('wmoa-success').show();
            return;
        }
  
        otpMessage.hide(); // Clear previous messages
        verifyOtpBtn.addClass('loading').prop("disabled", true);
  
        $.ajax({
            url: wmoa_ajax.ajax_url,
            type: 'POST',
            data: { 
                action: 'verify_otp', 
                phone: phone, 
                otp: otp, 
                nonce: wmoa_ajax.nonce 
            },
            dataType: 'json',
            success: function(response) {
                verifyOtpBtn.removeClass('loading').prop("disabled", false);
  
                if (response.success) {
                    otpMessage.text(response.data.message).addClass('wmoa-success').removeClass('wmoa-error').show();
                    $('#phone-register-form').append('<input type="hidden" name="otp_verified" value="1">');
                    $('#phone-register-form').submit();
                } else {
                    otpMessage.text(response.data.message || 'Unknown error').addClass('wmoa-error').removeClass('wmoa-success').show();
                }
            },
            error: function(xhr, status, error) {
                verifyOtpBtn.removeClass('loading').prop("disabled", false);
                let message = 'Error verifying OTP: ' + (xhr.responseText || 'Unknown error');
                try {
                    const parsed = JSON.parse(xhr.responseText);
                    if (parsed.data && parsed.data.message) {
                        message = parsed.data.message;
                    }
                } catch (e) {
                    // Ignore parsing error
                }
                otpMessage.text(message).addClass('wmoa-error').removeClass('wmoa-success').show();
            }
        });
    });
  
    // Login: Restrict phone input to 10 digits
    loginPhoneInput.on("input", function() {
        $(this).val($(this).val().replace(/\D/g, '').substring(0, 10));
    });
  
    // Login: Handle "Get OTP" button click
    loginSendOtpBtn.on("click", function() {
        const phone = loginPhoneInput.val().trim();
        if (!phone) {
            loginPhoneError.text("Phone number is required.").show();
            return;
        }
        if (phone.length !== 10) {
            loginPhoneError.text("Enter a valid 10-digit phone number.").show();
            return;
        }
        loginPhoneError.hide();
        loginOtpMessage.hide(); // Clear previous messages
  
        loginSendOtpBtn.addClass('loading').prop("disabled", true);
  
        $.ajax({
            url: wmoa_ajax.ajax_url,
            type: 'POST',
            data: { 
                action: 'wmoa_login_send_otp', 
                phone: phone, 
                nonce: wmoa_ajax.nonce 
            },
            dataType: 'json',
            success: function(response) {
                loginSendOtpBtn.removeClass('loading').prop("disabled", false);
  
                if (response.success) {
                    loginOtpMessage.text(response.data.message).addClass('wmoa-success').removeClass('wmoa-error').show();
                    loginOtpSection.show();
                    startResendTimer(loginResendTimer, loginResendOtpLink, 60);
                } else {
                    loginPhoneError.text(response.data.message || 'Unknown error').addClass('wmoa-error').removeClass('wmoa-success').show();
                }
            },
            error: function(xhr, status, error) {
                loginSendOtpBtn.removeClass('loading').prop("disabled", false);
                let message = 'Error sending OTP: ' + (xhr.responseText || 'Unknown error');
                try {
                    const parsed = JSON.parse(xhr.responseText);
                    if (parsed.data && parsed.data.message) {
                        message = parsed.data.message;
                    }
                } catch (e) {
                    // Ignore parsing error
                }
                loginPhoneError.text(message).addClass('wmoa-error').removeClass('wmoa-success').show();
            }
        });
    });
  
    // Login: Handle "Resend OTP" click
    loginResendOtpLink.on('click', function(e) {
        e.preventDefault();
        if ($(this).hasClass('disabled')) return;
  
        loginSendOtpBtn.trigger('click');
    });
  
    // Login: Handle "Verify OTP" button click
    loginVerifyOtpBtn.on("click", function() {
        const phone = loginPhoneInput.val().trim();
        const otp = loginOtpInput.val();
  
        if (otp.length !== 6) {
            loginOtpMessage.text("Enter a valid 6-digit OTP.").addClass('wmoa-error').removeClass('wmoa-success').show();
            return;
        }
  
        loginOtpMessage.hide(); // Clear previous messages
        loginVerifyOtpBtn.addClass('loading').prop("disabled", true);
  
        $.ajax({
            url: wmoa_ajax.ajax_url,
            type: 'POST',
            data: { 
                action: 'wmoa_login_verify_otp', 
                phone: phone, 
                otp: otp, 
                nonce: wmoa_ajax.nonce 
            },
            dataType: 'json',
            success: function(response) {
                loginVerifyOtpBtn.removeClass('loading').prop("disabled", false);
  
                if (response.success) {
                    loginOtpMessage.text(response.data.message).addClass('wmoa-success').removeClass('wmoa-error').show();
                    window.location.reload();
                } else {
                    loginOtpMessage.text(response.data.message || 'Unknown error').addClass('wmoa-error').removeClass('wmoa-success').show();
                }
            },
            error: function(xhr, status, error) {
                loginVerifyOtpBtn.removeClass('loading').prop("disabled", false);
                let message = 'Error verifying OTP: ' + (xhr.responseText || 'Unknown error');
                try {
                    const parsed = JSON.parse(xhr.responseText);
                    if (parsed.data && parsed.data.message) {
                        message = parsed.data.message;
                    }
                } catch (e) {
                    // Ignore parsing error
                }
                loginOtpMessage.text(message).addClass('wmoa-error').removeClass('wmoa-success').show();
            }
        });
    });
  });