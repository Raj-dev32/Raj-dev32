<?php
/**
 * Custom Login and Registration Template for WooCommerce Mobile OTP Auth
 *
 * Overrides the default WooCommerce login/registration form with a custom OTP-based form.
 *
 * @package WooCommerceMobileOTPAuth
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

if (is_user_logged_in()) {
    return;
}

// Only render on the main My Account page (not on subpages like orders, edit-account, etc.)
if (!is_wc_endpoint_url() || is_wc_endpoint_url('dashboard')) {
    // Include the login and registration classes
    if (!class_exists('WMOA_Login') || !class_exists('WMOA_Registration')) {
        return;
    }
    ?>
    <div class="wmoa-main-wrapper">
        <?php
        // Render login form
        $login = new WMOA_Login();
        $login->custom_login_form();

        // Render registration form
        $registration = new WMOA_Registration();
        $registration->custom_registration_form();
        ?>
    </div>
    <?php
}