<?php
/**
 * Empty template to prevent default WooCommerce form rendering.
 *
 * @package WooCommerceMobileOTPAuth
 */