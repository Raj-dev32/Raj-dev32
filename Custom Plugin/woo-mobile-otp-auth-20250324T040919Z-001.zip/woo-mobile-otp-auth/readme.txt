=== WooCommerce Mobile OTP Auth ===
Contributors: yourname
Donate link: https://yourwebsite.com/donate/
Tags: woocommerce, otp, registration, login, sms, bulksms, authentication
Requires at least: 5.0
Tested up to: 6.5
Stable tag: 1.5
Requires PHP: 7.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Enables WooCommerce users to register and login using OTP verification via SMS with a modern UI and BulkSMS integration.

== Description ==

WooCommerce Mobile OTP Auth enhances your WooCommerce store by allowing customers to register and log in using their mobile numbers with OTP (One-Time Password) verification. It replaces the default WooCommerce registration form with a mobile-first approach, sending OTPs via the BulkSMS API. The plugin features a clean, responsive UI and seamless integration with WooCommerce.

Key features:
- Register with a mobile number and OTP verification.
- Login using a mobile number (optional OTP login can be added).
- BulkSMS API integration for sending OTPs.
- Modern, responsive UI with AJAX-powered OTP requests.
- WooCommerce dependency check for compatibility.

== Installation ==

1. Upload the `woo-mobile-otp-auth` folder to the `/wp-content/plugins/` directory, or install the plugin ZIP file via the WordPress admin panel (Plugins > Add New > Upload Plugin).
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Ensure WooCommerce is installed and active (the plugin will not work without it).
4. The OTP registration form will automatically replace the default WooCommerce registration form on the My Account page.

== Frequently Asked Questions ==

= Does this plugin require WooCommerce? =
Yes, WooCommerce Mobile OTP Auth is designed to work with WooCommerce and requires it to be installed and active.

= How does the plugin send OTPs? =
It uses the BulkSMS API. The current version has hardcoded credentials, but you can modify the code or request a settings page for custom API keys.

= Can I translate the plugin? =
Yes, the plugin is translation-ready. Place your `.mo` and `.po` files in the `languages` folder and use the `woo-mobile-otp-auth` text domain.

= Does it support login with OTP? =
The current version supports login with a phone number without OTP. Contact the author to request OTP login functionality.

== Screenshots ==

1. Registration form with mobile number input and "Get OTP" button.
2. OTP verification step with a clean, centered UI.

== Changelog ==

= 1.5 =
* Added AJAX-based OTP registration with BulkSMS integration.
* Improved UI with responsive design and custom CSS.
* Made plugin translation-ready with a `languages` folder.

= 1.0 =
* Initial release with basic OTP registration functionality.

== Upgrade Notice ==

= 1.5 =
This update includes a modern UI, AJAX OTP handling, and translation support. Back up your site before upgrading.

== License ==
This plugin is licensed under the GPLv2 or later. See the License URI for details.