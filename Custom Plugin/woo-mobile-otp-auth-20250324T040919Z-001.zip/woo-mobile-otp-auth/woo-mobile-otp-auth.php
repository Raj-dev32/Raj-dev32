<?php
/**
 * Plugin Name: WooCommerce Mobile OTP Auth
 * Description: Replaces WooCommerce default forms with OTP-based registration and login using BulkSMS integration.
 * Version: 1.5
 * Author: Your Name
 * Author URI: https://yourwebsite.com/
 * Text Domain: woo-mobile-otp-auth
 * Domain Path: /languages
 * License: GPL v2 or later
 * Requires at least: 5.0
 * Tested up to: 6.6
 * Requires PHP: 7.4
 * WC requires at least: 3.0
 * WC tested up to: 9.3
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Declare HPOS compatibility.
 */
add_action('before_woocommerce_init', function() {
    if (class_exists('\Automattic\WooCommerce\Utilities\FeaturesUtil')) {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('custom_order_tables', __FILE__, true);
    }
});

/**
 * Check if WooCommerce is active.
 */
function wmoa_check_woocommerce_dependency() {
    if (!class_exists('WooCommerce')) {
        deactivate_plugins(plugin_basename(__FILE__));
        wp_die(__('WooCommerce Mobile OTP Auth requires WooCommerce to be installed and active. Please install and activate WooCommerce.', 'woo-mobile-otp-auth'));
    }
}
register_activation_hook(__FILE__, 'wmoa_check_woocommerce_dependency');

/**
 * Initialize the plugin.
 */
function wmoa_init_plugin() {
    if (!class_exists('WooCommerce')) {
        add_action('admin_notices', 'wmoa_woocommerce_missing_notice');
        return;
    }

    // Load text domain for translations
    load_plugin_textdomain('woo-mobile-otp-auth', false, dirname(plugin_basename(__FILE__)) . '/languages/');

    // Enqueue Font Awesome
    wp_enqueue_style('font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css', [], '6.4.0');

    // Include core class
    require_once plugin_dir_path(__FILE__) . 'includes/class-wmoa-core.php';

    // Instantiate the core class
    $wmoa_core = new WMOA_Core();
    $wmoa_core->init();
}
add_action('plugins_loaded', 'wmoa_init_plugin');

/**
 * Display admin notice if WooCommerce is missing.
 */
function wmoa_woocommerce_missing_notice() {
    echo '<div class="error"><p>' . esc_html__('WooCommerce Mobile OTP Auth requires WooCommerce to be installed and active.', 'woo-mobile-otp-auth') . '</p></div>';
}