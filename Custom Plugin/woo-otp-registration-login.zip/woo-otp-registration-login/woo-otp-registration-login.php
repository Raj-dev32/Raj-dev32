<?php
/*
 * Plugin Name: WooCommerce OTP Registration & Login
 * Description: Enables users to register and login using OTP verification SMS with improved UI.
 * Author: Your Name
 * Version: 1.8
 * Requires at least: 5.0
 * Tested up to: 6.4
 * Requires PHP: 7.0
 * Text Domain: woo-otp
 * Domain Path: /languages
 * WC requires at least: 3.0
 * WC tested up to: 8.0
 */

if (!defined('ABSPATH')) {
    exit;
}

// Define constants
define('WOO_OTP_VERSION', '1.8');
define('WOO_OTP_PATH', plugin_dir_path(__FILE__));
define('WOO_OTP_URL', plugin_dir_url(__FILE__));

add_action('before_woocommerce_init', function() {
    if (class_exists('\Automattic\WooCommerce\Utilities\FeaturesUtil')) {
        \Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility('custom_order_tables', __FILE__, true);
    }
});

// Main Plugin Class
class Woo_OTP_Plugin {
    private static $instance = null;

    public static function get_instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->load_dependencies();

        if (!$this->check_dependencies()) {
            add_action('admin_notices', [$this, 'admin_notice_missing_woocommerce']);
            return;
        }

        // Initialize core functionality
        Woo_OTP_Core::get_instance();
        Woo_OTP_Ajax::get_instance();
        
        if (is_admin()) {
            Woo_OTP_Settings::get_instance();
        }
    }

    private function load_dependencies() {
        require_once WOO_OTP_PATH . 'includes/class-woo-otp-core.php';
        require_once WOO_OTP_PATH . 'includes/class-woo-otp-settings.php';
        require_once WOO_OTP_PATH . 'includes/class-woo-otp-ajax.php';
    }

    private function check_dependencies() {
        return class_exists('WooCommerce');
    }

    public function admin_notice_missing_woocommerce() {
        ?>
        <div class="notice notice-error">
            <p><?php _e('WooCommerce OTP Registration & Login requires WooCommerce to be installed and active.', 'woo-otp'); ?></p>
        </div>
        <?php
    }
}

// Initialize plugin
function woo_otp_init() {
    Woo_OTP_Plugin::get_instance();
}
add_action('plugins_loaded', 'woo_otp_init');

// Load text domain
function woo_otp_load_textdomain() {
    load_plugin_textdomain('woo-otp', false, dirname(plugin_basename(__FILE__)) . '/languages');
}
add_action('init', 'woo_otp_load_textdomain');