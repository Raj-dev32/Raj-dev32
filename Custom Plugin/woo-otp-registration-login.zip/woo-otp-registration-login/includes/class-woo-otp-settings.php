<?php
if (!defined('ABSPATH')) {
    exit;
}

class Woo_OTP_Settings {
    private static $instance = null;

    public static function get_instance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        add_filter('woocommerce_settings_tabs_array', [$this, 'add_settings_tab'], 50);
        add_action('woocommerce_settings_tabs_otp_settings', [$this, 'settings_tab']);
        add_action('woocommerce_update_options_otp_settings', [$this, 'update_settings']);
    }

    public function add_settings_tab($settings_tabs) {
        $settings_tabs['otp_settings'] = __('OTP Settings', 'woo-otp');
        return $settings_tabs;
    }

    public function settings_tab() {
        woocommerce_admin_fields($this->get_settings());
    }

    public function update_settings() {
        woocommerce_update_options($this->get_settings());
    }

    public function get_settings() {
        $settings = array(
            'section_title' => array(
                'name'     => __('OTP Settings', 'woo-otp'),
                'type'     => 'title',
                'desc'     => 'Configure OTP Registration & Login settings',
                'id'       => 'woo_otp_settings_title'
            ),
            'enable_otp' => array(
                'name'     => __('Enable OTP', 'woo-otp'),
                'type'     => 'checkbox',
                'desc'     => __('Enable OTP verification for registration and login', 'woo-otp'),
                'id'       => 'woo_otp_enable',
                'default'  => 'yes'
            ),
            'test_mode' => array(
                'name'     => __('Test Mode', 'woo-otp'),
                'type'     => 'checkbox',
                'desc'     => __('Enable test mode (OTP will be logged to console instead of sending SMS)', 'woo-otp'),
                'id'       => 'woo_otp_test_mode',
                'default'  => 'no'
            ),
            'sms_api_section' => array(
                'name'     => __('SMS API Settings', 'woo-otp'),
                'type'     => 'title',
                'desc'     => '',
                'id'       => 'woo_otp_sms_api_section'
            ),
            'sms_username' => array(
                'name'     => __('SMS API Username', 'woo-otp'),
                'type'     => 'text',
                'desc'     => __('Enter your SMS API username', 'woo-otp'),
                'id'       => 'woo_otp_sms_username',
                'default'  => 'arutoys',
                'css'      => 'min-width: 300px;'
            ),
            'sms_password' => array(
                'name'     => __('SMS API Password', 'woo-otp'),
                'type'     => 'password',
                'desc'     => __('Enter your SMS API password', 'woo-otp'),
                'id'       => 'woo_otp_sms_password',
                'default'  => 'OlixLab$1',
                'css'      => 'min-width: 300px;'
            ),
            'sms_api_url' => array(
                'name'     => __('SMS API URL', 'woo-otp'),
                'type'     => 'text',
                'desc'     => __('Enter your SMS API endpoint URL', 'woo-otp'),
                'id'       => 'woo_otp_sms_api_url',
                'default'  => 'https://api.bulksms.com/v1/messages?auto-unicode=true&longMessageMaxParts=30',
                'css'      => 'min-width: 400px;'
            ),
            'sms_sender_id' => array(
                'name'     => __('Sender ID', 'woo-otp'),
                'type'     => 'text',
                'desc'     => __('Enter the sender ID for SMS messages', 'woo-otp'),
                'id'       => 'woo_otp_sms_sender_id',
                'default'  => 'AruToys',
                'css'      => 'min-width: 200px;'
            ),
            'sms_text_section' => array(
                'name'     => __('SMS Message Settings', 'woo-otp'),
                'type'     => 'title',
                'desc'     => '',
                'id'       => 'woo_otp_sms_text_section'
            ),
            'register_sms' => array(
                'name'     => __('Registration SMS Text', 'woo-otp'),
                'type'     => 'textarea',
                'desc'     => __('SMS text for registration. Use {otp} as placeholder for OTP code', 'woo-otp'),
                'id'       => 'woo_otp_register_sms',
                'default'  => 'Welcome to Arutoys! Your OTP is {otp}.',
                'css'      => 'min-width: 400px; height: 100px;'
            ),
            'login_sms' => array(
                'name'     => __('Login SMS Text', 'woo-otp'),
                'type'     => 'textarea',
                'desc'     => __('SMS text for login. Use {otp} as placeholder for OTP code', 'woo-otp'),
                'id'       => 'woo_otp_login_sms',
                'default'  => 'Welcome to Arutoys! Your Login OTP is {otp}.',
                'css'      => 'min-width: 400px; height: 100px;'
            ),
            'section_end' => array(
                'type'     => 'sectionend',
                'id'       => 'woo_otp_settings_end'
            )
        );
        return apply_filters('woo_otp_settings', $settings);
    }
}