<?php if (!defined('ABSPATH')) exit; ?>
<form method="post" id="phone-register-form" class="otp-form">
    <h2><?php _e('Registration By Phone Number', 'woo-otp'); ?></h2>
    <p class="form-row">
        <label for="reg_billing_phone"><?php _e('Phone Number', 'woo-otp'); ?><span class="required">*</span></label>
        <span style="display: flex; align-items: center;">
            <span style="padding: 9px; background: #f1f1f1; border: 1px solid #ccc;">+91</span>
            <input type="text" class="input-text" name="billing_phone" id="reg_billing_phone" maxlength="10" required style="flex: 1; border-left: none;" />
        </span>
        <p id="reg-phone-error" style="color: red; display: none;"></p>
    </p>
    <p class="form-row">
        <button type="button" id="sendRegOtp" class="btn-color-primary"><?php _e('Get OTP', 'woo-otp'); ?></button>
    </p>
    <div id="reg-otp-section" style="display:none;">
        <p class="form-row">
            <label for="reg_otp_code"><?php _e('Enter OTP', 'woo-otp'); ?><span class="required">*</span></label>
            <input type="text" class="input-text" name="otp_code" id="reg_otp_code" maxlength="6" required />
        </p>
        <p class="form-row">
            <button type="button" id="verifyRegOtpBtn" class="btn-color-primary"><?php _e('Verify & Register', 'woo-otp'); ?></button>
        </p>
        <p id="reg-otp-message" style="color: red; display: none;"></p>
    </div>
</form>