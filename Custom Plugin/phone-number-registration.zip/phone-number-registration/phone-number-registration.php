<?php
/*
  * Plugin Name: WooCommerce OTP Registration
  * Description: Enables users to register using OTP verification SMS with an improved UI.
  * Author: Your Name
  * Version: 1.5
*/

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Enqueue scripts and styles
 */
function woo_enqueue_scripts() {
    wp_enqueue_style('dashicons');
    wp_enqueue_script('jquery');
    wp_localize_script('jquery', 'woo_ajax', array(
        'ajax_url' => admin_url('admin-ajax.php'),
        'nonce' => wp_create_nonce('woo_nonce')
    ));
}
add_action('wp_enqueue_scripts', 'woo_enqueue_scripts');

/**
 * Custom OTP Registration Form
 */
function woo_custom_otp_registration_form() {
    if (is_user_logged_in()) {
        echo '<p>' . __('You are already logged in.', 'woocommerce') . '</p>';
        return;
    }

    ob_start(); ?>
    
    <form method="post" id="phone-register-form">
        <p class="form-row">
            <label for="reg_billing_phone"><?php _e('Phone Number', 'woocommerce'); ?><span class="required">*</span></label>
            <span style="display: flex; align-items: center;">
                <span style="padding: 9px; background: #f1f1f1; border: 1px solid #ccc;">+91</span>
                <input type="text" class="input-text" name="billing_phone" id="reg_billing_phone" maxlength="10" required style="flex: 1; border-left: none;" />
            </span>
            <p id="phone-error" style="color: red; display: none;"></p>
        </p>

        <p class="form-row">
            <button type="button" id="sendOtp" class="btn-color-primary">Get OTP</button>
        </p>

        <div id="otp-section" style="display:none;">
            <p class="form-row">
                <label for="otp_code"><?php _e('Enter OTP', 'woocommerce'); ?><span class="required">*</span></label>
                <input type="text" class="input-text" name="otp_code" id="otp_code" maxlength="6" required />
            </p>

            <p class="form-row">
                <button type="button" id="verifyOtpBtn" class="btn-color-primary">Verify OTP</button>
            </p>

            <p id="otp-message" style="color: red; display: none;"></p>
        </div>
    </form>

    <script>
        jQuery(document).ready(function($) {
            let phoneInput = $('#reg_billing_phone');
            let sendOtpBtn = $('#sendOtp');
            let otpSection = $('#otp-section');
            let otpInput = $('#otp_code');
            let verifyOtpBtn = $('#verifyOtpBtn');
            let otpMessage = $('#otp-message');
            let phoneError = $('#phone-error');

            phoneInput.on("input", function() {
                $(this).val($(this).val().replace(/\D/g, '').substring(0, 10));
            });

            sendOtpBtn.on("click", function() {
                let phone = phoneInput.val();
                if (phone.length !== 10) {
                    phoneError.text("Enter a valid 10-digit phone number.").show();
                    return;
                }
                phoneError.hide();

                sendOtpBtn.text("Sending...").prop("disabled", true);

                $.post(woo_ajax.ajax_url, { 
                    action: 'send_otp', 
                    phone: phone, 
                    nonce: woo_ajax.nonce 
                }, function(response) {
                    sendOtpBtn.text("Get OTP").prop("disabled", false);

                    if (response.success) {
                        otpMessage.text("OTP sent successfully!").css("color", "green").show();
                        otpSection.show();
                    } else {
                        otpMessage.text("Failed to send OTP. Try again.").css("color", "red").show();
                    }
                });
            });

            verifyOtpBtn.on("click", function() {
                let phone = phoneInput.val();
                let otp = otpInput.val();

                if (otp.length !== 6) {
                    otpMessage.text("Enter a valid 6-digit OTP.").css("color", "red").show();
                    return;
                }

                verifyOtpBtn.text("Verifying...").prop("disabled", true);

                $.post(woo_ajax.ajax_url, { 
                    action: 'verify_otp', 
                    phone: phone, 
                    otp: otp, 
                    nonce: woo_ajax.nonce 
                }, function(response) {
                    verifyOtpBtn.text("Verify OTP").prop("disabled", false);

                    if (response.success) {
                        otpMessage.text("OTP verified! Registering...").css("color", "green").show();
                        $('#phone-register-form').append('<input type="hidden" name="otp_verified" value="1">');
                        $('#phone-register-form').submit();
                    } else {
                        otpMessage.text("Invalid OTP. Please try again.").css("color", "red").show();
                    }
                });
            });
        });
    </script>
    <style>
        .btn-color-primary {
            --btn-color: #fff;
            --btn-color-hover: #fff;
            --btn-bgcolor: var(--wd-primary-color);
            --btn-bgcolor-hover: var(--wd-primary-color);
            --btn-brd-color: var(--wd-primary-color);
            --btn-brd-color-hover: var(--wd-primary-color);
            --btn-box-shadow-hover: inset 0 0 0 1000px rgba(0, 0, 0, 0.1);
        }
    </style>

    <?php
    return ob_get_clean();
}
add_shortcode('otp_registration_form', 'woo_custom_otp_registration_form');

/**
 * Handle OTP sending
 */
function woo_send_otp() {
    if (!isset($_POST['phone'])) {
        wp_send_json_error(['message' => 'Phone number missing']);
        return;
    }

    $phone = sanitize_text_field($_POST['phone']);
    
    // Check if OTP was sent recently
    $last_sent = get_option("otp_last_sent_$phone");
    if ($last_sent && (time() - $last_sent < 60)) { // 60 seconds limit
        wp_send_json_error(['message' => 'Please wait before requesting a new OTP.']);
        return;
    }

    $otp = rand(100000, 999999);
    update_option("otp_$phone", $otp, false);
    update_option("otp_last_sent_$phone", time(), false);

    $username = 'arutoys';
    $password = 'OlixLab$1';

    $api_url = 'https://api.bulksms.com/v1/messages?auto-unicode=true&longMessageMaxParts=30';
    $auth_header = 'Authorization: Basic ' . base64_encode("$username:$password");

    $message_data = json_encode([
        "from" => "AruToys",
        "to"   => "+91$phone",
        "routingGroup" => "ECONOMY",
        "encoding" => "TEXT",
        "numberOfParts" => 0,
        "body" => "Welcome to Arutoys! Your OTP is $otp."
    ]);

    $ch = curl_init($api_url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        $auth_header
    ]);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $message_data);

    $response = curl_exec($ch);
    $http_status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($http_status !== 201) {
        wp_send_json_error(['message' => 'Error sending OTP']);
    } else {
        wp_send_json_success(['message' => 'OTP sent successfully']);
    }

    // Here you would send the OTP via SMS service
    // For testing, we will just return the OTP
    //wp_send_json_success(['message' => 'OTP sent successfully (Test Mode)', 'otp' => $otp]);
}
add_action('wp_ajax_send_otp', 'woo_send_otp');
add_action('wp_ajax_nopriv_send_otp', 'woo_send_otp');

/**
 * Handle OTP verification
 */
function woo_verify_otp() {
    if (!isset($_POST['phone']) || !isset($_POST['otp'])) {
        wp_send_json_error(['message' => 'Missing parameters']);
        return;
    }
    
    $phone = sanitize_text_field($_POST['phone']);
    $otp_entered = sanitize_text_field($_POST['otp']);
    $stored_otp = get_option("otp_$phone");

    if ($otp_entered != $stored_otp) {
        wp_send_json_error(['message' => 'Invalid OTP']);
    } else {
        delete_option("otp_$phone");
        wp_send_json_success(['message' => 'OTP verified']);
    }
}
add_action('wp_ajax_verify_otp', 'woo_verify_otp');
add_action('wp_ajax_nopriv_verify_otp', 'woo_verify_otp');

/**
 * Register user after OTP verification
 */
function woo_register_after_otp() {
    if (isset($_POST['otp_verified']) && $_POST['otp_verified'] == '1') {
        $phone = sanitize_text_field($_POST['billing_phone']);
        
        $existing_user = get_users([
            'meta_key' => 'billing_phone',
            'meta_value' => $phone,
            'number' => 1
        ]);

        if (!empty($existing_user)) {
            wc_add_notice(__('This phone number is already registered. Please log in.', 'woocommerce'), 'error');
            return;
        }

        $userdata = [
            'user_login' => $phone,
            'user_pass'  => wp_generate_password(),
            'role'       => 'customer'
        ];

        $user_id = wp_insert_user($userdata);
        update_user_meta($user_id, 'billing_phone', $phone);
        wp_set_current_user($user_id);
        wp_set_auth_cookie($user_id);

        wp_safe_redirect(site_url('/my-account/edit-account/'));
        exit();
    }
}
add_action('init', 'woo_register_after_otp');

/**
 * Allow login using phone number
 */
function woo_login_with_phone($user, $username, $password) {
    if (preg_match("/^[0-9]{10}$/", $username)) {
        $user_query = get_users([
            'meta_key' => 'billing_phone',
            'meta_value' => $username,
            'number' => 1
        ]);

        if (!empty($user_query)) {
            return get_user_by('ID', reset($user_query)->ID);
        }
    }
    return $user;
}
add_filter('authenticate', 'woo_login_with_phone', 20, 3);

/**
 * Validate phone number during registration
 */
function woo_validate_phone_field($username, $email, $validation_errors) {
    if (empty($_POST['billing_phone'])) {
        $validation_errors->add('billing_phone_error', __('Please provide a valid phone number.', 'woocommerce'));
    }
    return $validation_errors;
}
add_action('woocommerce_register_post', 'woo_validate_phone_field', 10, 3);

/**
 * Save phone number in user meta after registration
 */
function woo_save_phone_field($customer_id) {
    if (isset($_POST['billing_phone'])) {
        update_user_meta($customer_id, 'billing_phone', sanitize_text_field($_POST['billing_phone']));
    }
}
add_action('woocommerce_created_customer', 'woo_save_phone_field');

/**
 * Change WooCommerce login labels
 */
function woo_change_login_labels($translated, $text, $domain) {
    if (!is_admin() && 'woocommerce' === $domain && $text === 'Username or email address') {
        $translated = __('Phone number or email address', 'woocommerce');
    }
    return $translated;
}
add_filter('gettext', 'woo_change_login_labels', 10, 3);