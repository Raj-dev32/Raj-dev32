<?php
/*
 * Plugin Name: Image Alt Manager
 * Description: A plugin to manage and add alt text to images with a modern interface.
 * Version: 1.6.0
 * Author: Your Name
 * Text Domain: image-alt-manager
 */

if (!defined('ABSPATH')) {
    exit;
}

define('IAM_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('IAM_PLUGIN_URL', plugin_dir_url(__FILE__));

function iam_load_textdomain() {
    load_plugin_textdomain('image-alt-manager', false, dirname(plugin_basename(__FILE__)) . '/languages/');
}
add_action('plugins_loaded', 'iam_load_textdomain');

require_once IAM_PLUGIN_DIR . 'includes/class-iam-settings.php';
require_once IAM_PLUGIN_DIR . 'includes/class-iam-image-manager.php';
require_once IAM_PLUGIN_DIR . 'includes/class-iam-ajax.php';

function iam_init() {
    $settings = new IAM_Settings();
    $image_manager = new IAM_Image_Manager();
    $ajax = new IAM_Ajax();
}
add_action('plugins_loaded', 'iam_init');

function iam_register_admin_page() {
    add_menu_page(
        __('Image Alt Manager', 'image-alt-manager'),
        __('Image Alt Manager', 'image-alt-manager'),
        'manage_options',
        'image-alt-manager',
        array('IAM_Settings', 'settings_page_callback'),
        'dashicons-images-alt2',
        6
    );
}
add_action('admin_menu', 'iam_register_admin_page');

function iam_activate() {
    if (get_option('iam_show_all_images') === false) {
        update_option('iam_show_all_images', 1);
    }
}
register_activation_hook(__FILE__, 'iam_activate');