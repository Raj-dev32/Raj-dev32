<?php
if (!defined('ABSPATH')) {
    exit;
}

class IAM_Settings {
    public static function settings_page_callback() {
        ?>
        <div class="wrap iam-wrap">
            <h1 class="iam-title"><?php _e('Image Alt Manager', 'image-alt-manager'); ?></h1>
            <div class="iam-content">
                <?php IAM_Image_Manager::display_image_manager(); ?>
            </div>
        </div>
        <?php
    }
}